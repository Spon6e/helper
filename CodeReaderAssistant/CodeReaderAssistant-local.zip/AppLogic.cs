using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;

namespace CodeReaderAssistant;

public enum AppMode
{
    Translator,
    Programming
}

public enum ProgrammingLanguage
{
    Python,
    Cpp
}

public static class LocalAssistant
{
    private static readonly Dictionary<string, string> PythonTerms = new(StringComparer.OrdinalIgnoreCase)
    {
        ["and"] = "логическое И: оба условия должны быть истинными.",
        ["as"] = "задаёт псевдоним, например import numpy as np.",
        ["assert"] = "проверяет условие и сообщает об ошибке, если оно ложно.",
        ["async"] = "объявляет асинхронную функцию или блок.",
        ["await"] = "ожидает результат асинхронной операции.",
        ["break"] = "немедленно завершает ближайший цикл.",
        ["class"] = "объявляет класс — шаблон для объектов и их поведения.",
        ["continue"] = "пропускает остаток текущей итерации и переходит к следующей.",
        ["def"] = "объявляет функцию.",
        ["del"] = "удаляет имя, элемент коллекции или атрибут.",
        ["elif"] = "проверяет дополнительное условие после if.",
        ["else"] = "задаёт ветку, которая выполняется, если предыдущие условия не сработали.",
        ["for"] = "создаёт цикл по элементам последовательности или другого итерируемого объекта.",
        ["from"] = "используется для импорта конкретных объектов из модуля.",
        ["global"] = "указывает, что имя относится к глобальной области видимости.",
        ["if"] = "выполняет блок, когда условие истинно.",
        ["import"] = "подключает модуль или пакет.",
        ["in"] = "проверяет принадлежность или перебирает элементы в цикле.",
        ["is"] = "проверяет, ссылаются ли два имени на один и тот же объект.",
        ["lambda"] = "создаёт короткую анонимную функцию.",
        ["match"] = "сопоставляет значение с вариантами шаблонов.",
        ["not"] = "логическое отрицание.",
        ["None"] = "специальное значение, обозначающее отсутствие объекта или результата.",
        ["or"] = "логическое ИЛИ: достаточно истинности одного из условий.",
        ["pass"] = "пустая команда-заглушка, не выполняющая действий.",
        ["raise"] = "вручную выбрасывает исключение.",
        ["return"] = "возвращает значение из функции и завершает её выполнение.",
        ["try"] = "начинает блок, ошибки которого можно обработать через except.",
        ["except"] = "обрабатывает исключение из блока try.",
        ["finally"] = "блок, выполняющийся после try независимо от результата.",
        ["while"] = "повторяет блок, пока условие истинно.",
        ["with"] = "использует контекстный менеджер и автоматически выполняет завершающие действия.",
        ["yield"] = "возвращает промежуточное значение из генератора, сохраняя его состояние.",
        ["print"] = "выводит значения в консоль.",
        ["len"] = "возвращает количество элементов или символов.",
        ["range"] = "создаёт последовательность чисел, часто для циклов.",
        ["enumerate"] = "перебирает элементы вместе с их индексами.",
        ["zip"] = "объединяет несколько последовательностей по позициям.",
        ["list"] = "создаёт или обозначает изменяемый список.",
        ["dict"] = "создаёт или обозначает словарь пар ключ-значение.",
        ["set"] = "создаёт множество уникальных элементов.",
        ["tuple"] = "создаёт неизменяемую последовательность.",
        ["str"] = "преобразует значение в строку или обозначает строковый тип.",
        ["int"] = "преобразует значение в целое число.",
        ["float"] = "преобразует значение в число с плавающей точкой.",
        ["bool"] = "преобразует значение в True или False.",
        ["open"] = "открывает файл и возвращает файловый объект.",
        ["self"] = "ссылка на текущий экземпляр класса.",
        ["True"] = "логическое значение истина.",
        ["False"] = "логическое значение ложь.",
        ["__init__"] = "специальный метод-конструктор, вызываемый при создании объекта.",
        ["__name__"] = "специальное имя модуля; при запуске файла напрямую равно __main__.",
        ["abs"] = "возвращает абсолютное значение числа.",
        ["all"] = "возвращает True, если все элементы последовательности истинны.",
        ["any"] = "возвращает True, если хотя бы один элемент последовательности истинен.",
        ["bin"] = "преобразует целое число в двоичную строку.",
        ["bytes"] = "создаёт неизменяемую последовательность байтов.",
        ["callable"] = "проверяет, можно ли вызвать объект как функцию.",
        ["chr"] = "возвращает символ по его числовому коду Unicode.",
        ["complex"] = "создаёт комплексное число.",
        ["dir"] = "показывает доступные имена и атрибуты объекта.",
        ["eval"] = "вычисляет строку как выражение Python; применять с осторожностью.",
        ["exec"] = "выполняет строку или скомпилированный код Python; применять с осторожностью.",
        ["filter"] = "оставляет элементы, для которых функция возвращает True.",
        ["format"] = "форматирует значение в строку.",
        ["frozenset"] = "создаёт неизменяемое множество.",
        ["getattr"] = "получает атрибут объекта по имени.",
        ["hasattr"] = "проверяет наличие атрибута у объекта.",
        ["hash"] = "возвращает хеш объекта.",
        ["id"] = "возвращает уникальный идентификатор объекта в текущем запуске.",
        ["input"] = "читает строку из консоли.",
        ["isinstance"] = "проверяет, является ли объект экземпляром указанного типа.",
        ["issubclass"] = "проверяет, является ли класс наследником другого класса.",
        ["iter"] = "создаёт итератор из итерируемого объекта.",
        ["map"] = "применяет функцию к каждому элементу последовательности.",
        ["max"] = "возвращает максимальный элемент или значение.",
        ["min"] = "возвращает минимальный элемент или значение.",
        ["next"] = "получает следующий элемент итератора.",
        ["object"] = "базовый класс всех объектов Python.",
        ["ord"] = "возвращает числовой код Unicode символа.",
        ["pow"] = "возводит число в степень, возможно с модулем.",
        ["property"] = "создаёт свойство класса, доступное как атрибут.",
        ["repr"] = "возвращает техническое строковое представление объекта.",
        ["reversed"] = "возвращает итератор в обратном порядке.",
        ["round"] = "округляет число.",
        ["sorted"] = "возвращает новую отсортированную последовательность.",
        ["sum"] = "суммирует элементы последовательности.",
        ["super"] = "даёт доступ к реализации родительского класса.",
        ["vars"] = "возвращает словарь атрибутов объекта или текущей области.",
        ["os"] = "стандартный модуль для работы с операционной системой и путями.",
        ["sys"] = "модуль с параметрами интерпретатора и доступом к стандартным потокам.",
        ["json"] = "стандартный модуль для чтения и записи JSON.",
        ["math"] = "стандартный модуль математических функций.",
        ["random"] = "модуль генерации псевдослучайных чисел.",
        ["datetime"] = "модуль дат и времени.",
        ["pathlib"] = "модуль для удобной работы с путями файлов.",
        ["re"] = "модуль регулярных выражений.",
        ["collections"] = "набор специализированных контейнеров.",
        ["itertools"] = "инструменты для построения итераторов.",
        ["functools"] = "утилиты для функций и декораторов.",
        ["typing"] = "подсказки типов и типовые конструкции.",
        ["asyncio"] = "библиотека асинхронного программирования.",
        ["requests"] = "сторонняя библиотека для HTTP-запросов.",
        ["numpy"] = "библиотека массивов и численных вычислений.",
        ["pandas"] = "библиотека таблиц и анализа данных.",
    };

    private static readonly Dictionary<string, string> CppTerms = new(StringComparer.OrdinalIgnoreCase)
    {
        ["auto"] = "позволяет компилятору вывести тип переменной из инициализатора.",
        ["bool"] = "логический тип со значением true или false.",
        ["break"] = "немедленно завершает ближайший цикл или switch.",
        ["case"] = "задаёт один из вариантов внутри switch.",
        ["catch"] = "обрабатывает исключение, выброшенное из блока try.",
        ["class"] = "объявляет пользовательский тип с данными и методами.",
        ["const"] = "помечает значение как неизменяемое через данное имя.",
        ["continue"] = "переходит к следующей итерации цикла.",
        ["delete"] = "освобождает динамически выделенную память через указатель.",
        ["do"] = "начинает цикл, тело которого выполнится минимум один раз.",
        ["double"] = "число с плавающей точкой двойной точности.",
        ["else"] = "ветка, выполняемая, если условие if ложно.",
        ["enum"] = "объявляет перечисление именованных констант.",
        ["for"] = "цикл с инициализацией, условием и шагом.",
        ["if"] = "выполняет блок, когда условие истинно.",
        ["include"] = "подключает содержимое заголовочного файла до компиляции.",
        ["int"] = "целочисленный тип.",
        ["namespace"] = "объединяет имена и помогает избегать конфликтов.",
        ["new"] = "выделяет объект или массив в динамической памяти.",
        ["nullptr"] = "нулевой указатель, не указывающий на объект.",
        ["private"] = "делает члены класса доступными только из самого класса.",
        ["protected"] = "ограничивает доступ классом и его наследниками.",
        ["public"] = "делает члены класса доступными из внешнего кода.",
        ["return"] = "возвращает значение из функции и завершает её.",
        ["short"] = "целочисленный тип меньшей разрядности.",
        ["sizeof"] = "возвращает размер типа или объекта в байтах.",
        ["static"] = "меняет время жизни, связь или принадлежность переменной/метода.",
        ["std"] = "стандартное пространство имён C++.",
        ["string"] = "тип std::string для хранения текста.",
        ["struct"] = "объявляет пользовательский тип; по умолчанию члены публичны.",
        ["switch"] = "выбирает ветку выполнения по значению выражения.",
        ["template"] = "объявляет обобщённый код, работающий с разными типами.",
        ["this"] = "указатель на текущий объект.",
        ["throw"] = "выбрасывает исключение.",
        ["try"] = "начинает блок, в котором могут возникнуть исключения.",
        ["using"] = "подключает имя из пространства имён или задаёт псевдоним типа.",
        ["virtual"] = "разрешает переопределение метода в производном классе.",
        ["void"] = "обозначает отсутствие возвращаемого значения или тип без значения.",
        ["vector"] = "динамический массив из стандартной библиотеки.",
        ["while"] = "повторяет блок, пока условие истинно.",
        ["cout"] = "выводит данные в стандартный поток через оператор <<.",
        ["cin"] = "считывает данные из стандартного ввода через оператор >>.",
        ["endl"] = "добавляет перевод строки и сбрасывает буфер вывода.",
        ["make_unique"] = "создаёт std::unique_ptr с безопасным управлением памятью.",
        ["make_shared"] = "создаёт std::shared_ptr с подсчётом владельцев.",
        ["alignas"] = "задаёт требование к выравниванию объекта или типа.",
        ["alignof"] = "возвращает требуемое выравнивание типа.",
        ["asm"] = "встраивает ассемблерную инструкцию; зависит от компилятора.",
        ["constexpr"] = "помечает выражение или функцию, вычислимую на этапе компиляции.",
        ["consteval"] = "требует обязательного вычисления функции на этапе компиляции.",
        ["constinit"] = "требует статической инициализации переменной.",
        ["co_await"] = "приостанавливает корутину до завершения асинхронной операции.",
        ["co_return"] = "завершает корутину и возвращает результат.",
        ["co_yield"] = "возвращает промежуточное значение из корутины.",
        ["decltype"] = "получает тип выражения без его выполнения.",
        ["default"] = "задаёт ветку по умолчанию или просит компилятор создать специальный метод.",
        ["explicit"] = "запрещает неявные преобразования через конструктор.",
        ["export"] = "объявляет экспортируемую сущность; используется в модульной системе C++.",
        ["extern"] = "сообщает, что объект или функция определены в другом месте.",
        ["friend"] = "даёт функции или классу доступ к закрытым членам другого класса.",
        ["inline"] = "разрешает несколько определений и может подсказать встраивание функции.",
        ["long"] = "задаёт целочисленный тип большей разрядности.",
        ["mutable"] = "разрешает менять поле даже внутри const-объекта.",
        ["noexcept"] = "указывает, что функция не должна выбрасывать исключения.",
        ["operator"] = "объявляет или перегружает оператор типа +, == или [].",
        ["override"] = "проверяет, что метод переопределяет виртуальный метод базового класса.",
        ["requires"] = "задаёт ограничения для шаблонов и концепций C++20.",
        ["signed"] = "задаёт знаковый целочисленный тип.",
        ["static_assert"] = "проверяет условие на этапе компиляции.",
        ["thread_local"] = "создаёт отдельный экземпляр переменной для каждого потока.",
        ["typedef"] = "создаёт псевдоним типа; в современном коде часто заменяется using.",
        ["typename"] = "обозначает зависимое имя типа в шаблоне или объявляет параметр типа.",
        ["union"] = "объявляет тип, члены которого используют одну область памяти.",
        ["unsigned"] = "задаёт беззнаковый целочисленный тип.",
        ["volatile"] = "сообщает компилятору, что значение может изменяться внешним кодом.",
        ["wchar_t"] = "целочисленный тип для широких символов.",
        ["unique_ptr"] = "умный указатель с единственным владельцем объекта.",
        ["shared_ptr"] = "умный указатель с совместным владением и подсчётом ссылок.",
        ["weak_ptr"] = "слабая ссылка на объект, управляемый shared_ptr.",
        ["move"] = "перемещает ресурсы объекта вместо копирования; обычно std::move.",
        ["forward"] = "сохраняет категорию ссылки при передаче в шаблоне.",
        ["array"] = "контейнер фиксированного размера std::array.",
        ["deque"] = "двусторонняя очередь std::deque.",
        ["list"] = "двусвязный список std::list.",
        ["map"] = "отсортированный контейнер пар ключ-значение std::map.",
        ["unordered_map"] = "хеш-таблица пар ключ-значение.",
        ["unordered_set"] = "хеш-множество уникальных значений.",
        ["queue"] = "очередь std::queue по принципу FIFO.",
        ["stack"] = "стек std::stack по принципу LIFO.",
        ["pair"] = "контейнер из двух значений std::pair.",
        ["tuple"] = "контейнер фиксированного набора значений разных типов.",
        ["optional"] = "объект, который может содержать значение или быть пустым.",
        ["variant"] = "объект, содержащий одно значение из нескольких типов.",
        ["any"] = "контейнер для значения произвольного типа.",
        ["function"] = "объект-обёртка для вызываемого объекта.",
        ["exception"] = "базовый класс стандартных исключений.",
        ["runtime_error"] = "исключение об ошибке, обнаруженной во время выполнения.",
        ["sort"] = "сортирует диапазон элементов.",
        ["find"] = "ищет значение в диапазоне.",
        ["getline"] = "читает строку из потока до символа перевода строки.",
        ["ifstream"] = "поток для чтения из файла.",
        ["ofstream"] = "поток для записи в файл.",
        ["mutex"] = "объект взаимного исключения для защиты общих данных.",
        ["lock_guard"] = "блокирует mutex на время жизни объекта-охранника.",
        ["thread"] = "поток выполнения std::thread.",
        ["future"] = "объект для получения результата асинхронной операции.",
        ["async"] = "запускает функцию асинхронно и возвращает future.",
    };

    private static readonly Dictionary<string, string> ProgramWords = new(StringComparer.OrdinalIgnoreCase)
    {
        ["a"] = "один", ["an"] = "один", ["the"] = "этот", ["this"] = "это",
        ["is"] = "является", ["are"] = "являются", ["was"] = "был", ["were"] = "были",
        ["be"] = "быть", ["to"] = "к", ["from"] = "из", ["in"] = "в", ["on"] = "на",
        ["at"] = "в", ["for"] = "для", ["with"] = "с", ["without"] = "без",
        ["and"] = "и", ["or"] = "или", ["not"] = "не", ["if"] = "если", ["else"] = "иначе",
        ["then"] = "тогда", ["than"] = "чем", ["when"] = "когда", ["while"] = "пока",
        ["do"] = "делать", ["does"] = "делает", ["did"] = "сделал", ["can"] = "может",
        ["could"] = "мог бы", ["should"] = "следует", ["will"] = "будет", ["would"] = "бы",
        ["what"] = "что", ["how"] = "как", ["why"] = "почему", ["where"] = "где",
        ["who"] = "кто", ["which"] = "который", ["mean"] = "означать", ["means"] = "означает",
        ["hello"] = "привет", ["world"] = "мир", ["please"] = "пожалуйста", ["thanks"] = "спасибо",
        ["code"] = "код", ["command"] = "команда", ["word"] = "слово", ["function"] = "функция",
        ["method"] = "метод", ["class"] = "класс", ["variable"] = "переменная", ["value"] = "значение",
        ["name"] = "имя", ["kind"] = "вид", ["way"] = "способ",
        ["time"] = "время", ["year"] = "год", ["day"] = "день", ["example"] = "пример",
        ["help"] = "помощь", ["use"] = "использовать", ["using"] = "используя", ["used"] = "используемый",
        ["get"] = "получить", ["set"] = "установить", ["make"] = "создать", ["check"] = "проверить",
        ["find"] = "найти", ["show"] = "показать", ["hide"] = "скрыть", ["wait"] = "ждать",
        ["work"] = "работать", ["works"] = "работает", ["working"] = "работающий", ["need"] = "нужен",
        ["allow"] = "разрешить", ["enable"] = "включить", ["disable"] = "отключить", ["before"] = "до",
        ["after"] = "после", ["inside"] = "внутри", ["outside"] = "снаружи", ["between"] = "между",
        ["type"] = "тип", ["file"] = "файл", ["folder"] = "папка", ["line"] = "строка",
        ["text"] = "текст", ["string"] = "строка", ["number"] = "число", ["list"] = "список",
        ["array"] = "массив", ["object"] = "объект", ["data"] = "данные", ["result"] = "результат",
        ["error"] = "ошибка", ["exception"] = "исключение", ["warning"] = "предупреждение",
        ["read"] = "читать", ["write"] = "писать", ["open"] = "открыть", ["close"] = "закрыть",
        ["create"] = "создать", ["delete"] = "удалить", ["add"] = "добавить", ["remove"] = "удалить",
        ["start"] = "запустить", ["stop"] = "остановить", ["run"] = "запустить", ["return"] = "вернуть",
        ["print"] = "вывести", ["input"] = "ввод", ["output"] = "вывод", ["true"] = "истина",
        ["false"] = "ложь", ["new"] = "новый", ["old"] = "старый", ["first"] = "первый",
        ["last"] = "последний", ["next"] = "следующий", ["previous"] = "предыдущий",
        ["select"] = "выбрать", ["selected"] = "выбранный", ["contains"] = "содержит",
        ["return value"] = "возвращаемое значение", ["hello world"] = "привет, мир",
        ["read file"] = "прочитать файл", ["write file"] = "записать файл",
        ["how does this work"] = "как это работает", ["what does this mean"] = "что это означает",
        ["for each"] = "для каждого", ["not found"] = "не найдено", ["access denied"] = "доступ запрещён",
        ["user"] = "пользователь", ["username"] = "имя пользователя", ["password"] = "пароль",
        ["email"] = "электронная почта", ["phone"] = "телефон", ["address"] = "адрес",
        ["id"] = "идентификатор", ["identifier"] = "идентификатор", ["index"] = "индекс",
        ["key"] = "ключ", ["keys"] = "ключи", ["label"] = "подпись", ["title"] = "заголовок",
        ["description"] = "описание", ["content"] = "содержимое", ["message"] = "сообщение",
        ["count"] = "количество", ["length"] = "длина", ["size"] = "размер", ["capacity"] = "ёмкость",
        ["width"] = "ширина", ["height"] = "высота", ["color"] = "цвет", ["position"] = "позиция",
        ["location"] = "расположение", ["path"] = "путь", ["url"] = "адрес URL", ["uri"] = "адрес URI",
        ["host"] = "хост", ["port"] = "порт", ["protocol"] = "протокол", ["version"] = "версия",
        ["config"] = "конфигурация", ["configuration"] = "конфигурация", ["settings"] = "настройки",
        ["option"] = "параметр", ["options"] = "параметры", ["parameter"] = "параметр", ["parameters"] = "параметры",
        ["param"] = "параметр", ["params"] = "параметры", ["argument"] = "аргумент", ["arguments"] = "аргументы",
        ["args"] = "аргументы", ["kwargs"] = "именованные аргументы", ["item"] = "элемент",
        ["element"] = "элемент", ["entry"] = "запись", ["record"] = "запись", ["row"] = "строка",
        ["column"] = "столбец", ["field"] = "поле", ["property"] = "свойство", ["attribute"] = "атрибут",
        ["source"] = "источник", ["target"] = "цель", ["destination"] = "назначение", ["parent"] = "родитель",
        ["child"] = "дочерний элемент", ["root"] = "корень", ["node"] = "узел", ["edge"] = "ребро",
        ["queue"] = "очередь", ["stack"] = "стек", ["buffer"] = "буфер", ["cache"] = "кэш",
        ["memory"] = "память", ["stream"] = "поток", ["reader"] = "читатель", ["writer"] = "писатель",
        ["parser"] = "анализатор", ["formatter"] = "форматировщик", ["serializer"] = "сериализатор",
        ["deserializer"] = "десериализатор", ["handler"] = "обработчик", ["callback"] = "обратный вызов",
        ["listener"] = "слушатель", ["observer"] = "наблюдатель", ["manager"] = "менеджер",
        ["controller"] = "контроллер", ["service"] = "сервис", ["client"] = "клиент", ["server"] = "сервер",
        ["worker"] = "рабочий поток", ["task"] = "задача", ["job"] = "задание", ["thread"] = "поток",
        ["lock"] = "блокировка", ["event"] = "событие", ["signal"] = "сигнал", ["state"] = "состояние",
        ["status"] = "статус", ["mode"] = "режим", ["level"] = "уровень", ["priority"] = "приоритет",
        ["current"] = "текущий", ["default"] = "по умолчанию",
        ["enabled"] = "включён", ["disabled"] = "отключён", ["active"] = "активный", ["inactive"] = "неактивный",
        ["visible"] = "видимый", ["hidden"] = "скрытый", ["empty"] = "пустой", ["valid"] = "действительный",
        ["invalid"] = "недействительный", ["success"] = "успех", ["failure"] = "ошибка", ["failed"] = "не выполнен",
        ["request"] = "запрос", ["response"] = "ответ", ["header"] = "заголовок", ["body"] = "тело",
        ["token"] = "токен", ["cookie"] = "cookie", ["session"] = "сеанс", ["connection"] = "соединение",
        ["connect"] = "подключить", ["disconnect"] = "отключить", ["fetch"] = "получить данные",
        ["send"] = "отправить", ["receive"] = "получить", ["update"] = "обновить", ["insert"] = "вставить",
        ["append"] = "добавить в конец", ["push"] = "добавить в стек", ["pop"] = "извлечь из стека",
        ["load"] = "загрузить", ["save"] = "сохранить", ["store"] = "сохранить", ["parse"] = "разобрать",
        ["format"] = "форматировать", ["convert"] = "преобразовать", ["validate"] = "проверить",
        ["process"] = "обработать", ["handle"] = "обработать", ["execute"] = "выполнить", ["calculate"] = "вычислить",
        ["compute"] = "вычислить", ["generate"] = "сгенерировать", ["build"] = "собрать", ["initialize"] = "инициализировать",
        ["init"] = "инициализация", ["cleanup"] = "очистка", ["reset"] = "сбросить", ["retry"] = "повторить",
        ["temp"] = "временный", ["temporary"] = "временный", ["random"] = "случайный", ["min"] = "минимум",
        ["max"] = "максимум", ["average"] = "среднее", ["total"] = "итого", ["sum"] = "сумма",
        ["http"] = "HTTP", ["json"] = "JSON", ["xml"] = "XML", ["api"] = "API", ["gui"] = "интерфейс",
        ["ui"] = "интерфейс", ["database"] = "база данных", ["db"] = "база данных", ["table"] = "таблица",
        ["query"] = "запрос", ["schema"] = "схема", ["model"] = "модель", ["view"] = "представление",
    };

    private static readonly Dictionary<string, string> RussianWords = LoadRussianWords();

    private sealed class ExternalDictionaryEntry
    {
        public string Word { get; set; } = string.Empty;
        public string Translation { get; set; } = string.Empty;
    }

    private static Dictionary<string, string> LoadRussianWords()
    {
        var words = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
        var dictionaryPath = Path.Combine(AppContext.BaseDirectory, "dictionary", "en-ru-10000.json");

        try
        {
            if (File.Exists(dictionaryPath))
            {
                var json = File.ReadAllText(dictionaryPath);
                var externalWords = JsonSerializer.Deserialize<List<ExternalDictionaryEntry>>(
                    json,
                    new JsonSerializerOptions { PropertyNameCaseInsensitive = true }) ?? [];

                foreach (var entry in externalWords)
                {
                    var word = entry.Word.Trim();
                    var translation = CompactTranslation(entry.Translation);
                    if (word.Length > 0 && translation.Length > 0)
                    {
                        words[word] = translation;
                    }
                }
            }
        }
        catch (IOException)
        {
            // The app can continue with the curated programming dictionary.
        }
        catch (JsonException)
        {
            // A damaged optional dictionary must not prevent the app from opening.
        }

        foreach (var pair in ProgramWords)
        {
            words[pair.Key] = pair.Value;
        }

        return words;
    }

    private static string CompactTranslation(string translation)
    {
        var compact = Regex.Split(translation ?? string.Empty, @"\|перевод=|\{\{|#")[0];
        compact = Regex.Replace(compact, @"\s+", " ").Trim(' ', ',', ';', '.');
        if (compact.Length == 0 || compact == "—")
        {
            return string.Empty;
        }

        if (compact.Length > 86)
        {
            var comma = compact.IndexOf(',');
            compact = comma > 0 && comma < 70
                ? compact[..comma]
                : compact[..83] + "...";
        }

        return compact;
    }

    public static string Analyze(string text, ProgrammingLanguage language)
    {
        var value = text.Trim();
        if (value.Length == 0)
        {
            return "Выделение пустое. Выделите слово, строку или фрагмент кода и нажмите Ctrl+Shift+Space.";
        }

        var terms = language == ProgrammingLanguage.Python ? PythonTerms : CppTerms;
        var languageName = language == ProgrammingLanguage.Python ? "Python" : "C++";
        var result = new StringBuilder();

        var trimmedLines = value.Split('\n', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        if (trimmedLines.Length > 1)
        {
            result.AppendLine(BuildStructureSummary(value, language));
            result.AppendLine();
        }

        var found = new List<(string Token, string Explanation)>();
        var candidates = Regex.Matches(value, @"[A-Za-z_][A-Za-z_0-9]*(?:::[A-Za-z_][A-Za-z_0-9]*)?")
            .Select(match => match.Value)
            .Distinct(StringComparer.OrdinalIgnoreCase);

        foreach (var candidate in candidates)
        {
            var lookup = candidate.Contains("::", StringComparison.Ordinal)
                ? candidate[(candidate.LastIndexOf("::", StringComparison.Ordinal) + 2)..]
                : candidate;
            if (terms.TryGetValue(lookup, out var explanation))
            {
                found.Add((candidate, explanation));
            }
        }

        if (found.Count > 0)
        {
            var displayed = found.Take(12).ToArray();
            for (var index = 0; index < displayed.Length; index++)
            {
                var item = displayed[index];
                result.AppendLine($"{item.Token} — {item.Explanation}");

                if (index == 0)
                {
                    var example = BuildExample(item.Token, language);
                    var usage = BuildUsage(item.Token, language);
                    if (example.Length > 0)
                    {
                        result.AppendLine();
                        result.AppendLine("Пример:");
                        result.AppendLine(example);
                    }

                    if (usage.Length > 0)
                    {
                        result.AppendLine();
                        result.AppendLine("Правильное использование:");
                        result.AppendLine(usage);
                    }
                }

                if (index < displayed.Length - 1)
                {
                    result.AppendLine();
                }
            }
        }
        else if (trimmedLines.Length == 1 && Regex.IsMatch(value, @"^[A-Za-z_][A-Za-z_0-9]*$"))
        {
            result.AppendLine($"«{value}» не найдено в локальной справочной базе {languageName}.");
            result.AppendLine("Скорее всего, это имя переменной, функции или класса из конкретного проекта.");
        }

        var syntax = BuildSyntaxHints(value, language);
        if (syntax.Count > 0)
        {
            result.AppendLine();
            foreach (var hint in syntax.Distinct())
            {
                result.AppendLine(hint);
            }
        }

        if (found.Count == 0 && syntax.Count == 0)
        {
            result.AppendLine("Фрагмент не похож на известную конструкцию из локальной справки.");
            result.AppendLine("Можно вставить более длинную строку — тогда приложение попробует определить её структуру.");
        }

        return result.ToString().TrimEnd();
    }

    private static string BuildExample(string token, ProgrammingLanguage language)
    {
        var separator = token.LastIndexOf("::", StringComparison.Ordinal);
        var name = (separator >= 0 ? token[(separator + 2)..] : token).ToLowerInvariant();
        if (language == ProgrammingLanguage.Python)
        {
            return name switch
            {
                "def" => "def greet(name):\n    return f\"Hello, {name}\"",
                "if" => "if score >= 60:\n    print(\"passed\")",
                "for" => "for item in items:\n    print(item)",
                "while" => "while queue:\n    item = queue.pop(0)",
                "with" => "with open(\"data.txt\", encoding=\"utf-8\") as file:\n    text = file.read()",
                "class" => "class User:\n    pass",
                "import" => "import json\ndata = json.loads(text)",
                "try" => "try:\n    value = int(text)\nexcept ValueError:\n    value = 0",
                "async" => "async def load():\n    return await fetch()",
                "await" => "result = await load_data()",
                "lambda" => "double = lambda value: value * 2",
                "list" => "names = [user.name for user in users]",
                "dict" => "user = {\"name\": \"Anna\", \"age\": 20}",
                "return" => "def total(items):\n    return sum(items)",
                "yield" => "def numbers():\n    yield 1\n    yield 2",
                "match" => "match command:\n    case \"start\":\n        run()",
                "none" => "value = None",
                _ => string.Empty,
            };
        }

        return name switch
        {
            "mutable" => "class User {\n    mutable int cachedLength = 0;\npublic:\n    int length() const {\n        return ++cachedLength;\n    }\n};",
            "const" => "const int maxUsers = 100;",
            "auto" => "auto count = users.size();",
            "unique_ptr" => "auto user = std::make_unique<User>();",
            "shared_ptr" => "auto user = std::make_shared<User>();",
            "vector" => "std::vector<int> values{1, 2, 3};",
            "class" => "class User {\npublic:\n    std::string name;\n};",
            "struct" => "struct Point {\n    int x{};\n    int y{};\n};",
            "if" => "if (score >= 60) {\n    std::cout << \"passed\";\n}",
            "for" => "for (const auto& item : items) {\n    process(item);\n}",
            "switch" => "switch (command) {\n    case 1: run(); break;\n    default: stop();\n}",
            "template" => "template <typename T>\nT max_value(T a, T b) { return a > b ? a : b; }",
            "thread" => "std::thread worker([] {\n    do_work();\n});\nworker.join();",
            "mutex" => "std::lock_guard<std::mutex> guard(dataMutex);",
            "nullptr" => "User* user = nullptr;",
            "constexpr" => "constexpr int bufferSize = 1024;",
            "include" => "#include <vector>",
            "return" => "int total() {\n    return 42;\n}",
            "namespace" => "namespace app {\n    class User {};\n}",
            "virtual" => "virtual void draw() const = 0;",
            "override" => "void draw() const override;",
            "string" => "std::string name = \"Anna\";",
            "cout" => "std::cout << \"Hello\" << std::endl;",
            "cin" => "std::cin >> age;",
            _ => string.Empty,
        };
    }

    private static string BuildUsage(string token, ProgrammingLanguage language)
    {
        var separator = token.LastIndexOf("::", StringComparison.Ordinal);
        var name = (separator >= 0 ? token[(separator + 2)..] : token).ToLowerInvariant();
        if (language == ProgrammingLanguage.Python)
        {
            return name switch
            {
                "with" => "Используйте для файлов, блокировок и других ресурсов, которые нужно гарантированно закрыть.",
                "try" => "Обрабатывайте ожидаемые исключения; не скрывайте ошибки пустым except.",
                "async" or "await" => "Применяйте вместе с асинхронными функциями, когда операция действительно может ждать ввод-вывод.",
                "lambda" => "Используйте для короткого выражения; для сложной логики лучше объявить def.",
                "class" => "Используйте для объекта с состоянием и поведением, а не для группы несвязанных функций.",
                "return" => "Возвращайте результат из функции и явно обрабатывайте его у вызывающего кода.",
                _ => string.Empty,
            };
        }

        return name switch
        {
            "mutable" => "Используйте только для внутреннего технического состояния, например кэша или счётчика; логическое состояние объекта менять не следует.",
            "unique_ptr" => "Предпочитайте, когда объектом владеет один владелец; память освобождается автоматически.",
            "shared_ptr" => "Используйте только при действительно совместном владении и избегайте лишних циклов ссылок.",
            "const" => "Помечайте значения и методы неизменяемыми, если они не должны менять наблюдаемое состояние.",
            "thread" => "Завершайте поток через join или корректно передавайте владение через std::jthread.",
            "mutex" => "Защищайте общий ресурс коротким блоком и используйте RAII-обёртки вроде lock_guard.",
            "template" => "Используйте для обобщённого кода, когда алгоритм не зависит от конкретного типа.",
            "virtual" or "override" => "Для переопределения базового поведения помечайте базовый метод virtual, а дочерний override.",
            _ => string.Empty,
        };
    }

    public static string Translate(string text)
    {
        var value = text.Trim();
        if (value.Length == 0)
        {
            return "Выделение пустое. Выделите английский текст и нажмите Ctrl+Shift+Space.";
        }

        var singleWord = Regex.Match(value, @"^[A-Za-z_][A-Za-z0-9_]*$");
        if (singleWord.Success)
        {
            var word = singleWord.Value;
            var translatedWord = TranslateIdentifier(word);
            return translatedWord != word
                ? $"{word}  →  {translatedWord}"
                : $"{word}  →  нет в локальном словаре";
        }

        var result = value;
        foreach (var phrase in RussianWords.Where(item => item.Key.Contains(' ')).OrderByDescending(item => item.Key.Length))
        {
            result = Regex.Replace(result, $@"\b{Regex.Escape(phrase.Key)}\b", phrase.Value, RegexOptions.IgnoreCase);
        }

        result = Regex.Replace(result, @"[A-Za-z_][A-Za-z0-9_]*(?:'[A-Za-z]+)?", match =>
        {
            return TranslateIdentifier(match.Value);
        });

        return "Перевод:\r\n" + result;
    }

    private static string TranslateIdentifier(string identifier)
    {
        if (RussianWords.TryGetValue(identifier, out var directTranslation))
        {
            return PreserveCase(identifier, directTranslation);
        }

        if (identifier.StartsWith("__", StringComparison.Ordinal)
            && identifier.EndsWith("__", StringComparison.Ordinal))
        {
            return identifier;
        }

        var spaced = Regex.Replace(identifier, @"([A-Z]+)([A-Z][a-z])", "$1 $2");
        spaced = Regex.Replace(spaced, @"([a-z0-9])([A-Z])", "$1 $2");
        var parts = spaced.Split('_', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
            .SelectMany(part => part.Split(' ', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            .ToArray();

        if (parts.Length < 2)
        {
            return identifier;
        }

        var translatedParts = parts.Select(part =>
            RussianWords.TryGetValue(part, out var translation) ? translation : part).ToArray();
        var changed = translatedParts.Where((part, index) => part != parts[index]).Any();
        return changed
            ? string.Join(" ", translatedParts)
            : identifier;
    }

    private static string PreserveCase(string source, string translated)
    {
        if (source.Length > 0 && char.IsUpper(source[0]))
        {
            return char.ToUpper(translated[0]) + translated[1..];
        }

        return translated;
    }

    private static string BuildStructureSummary(string text, ProgrammingLanguage language)
    {
        var parts = new List<string>();
        if (language == ProgrammingLanguage.Python)
        {
            if (Regex.IsMatch(text, @"\bdef\s+\w+\s*\(")) parts.Add("объявляет функцию");
            if (Regex.IsMatch(text, @"\bclass\s+\w+")) parts.Add("объявляет класс");
            if (Regex.IsMatch(text, @"\b(for|while)\b")) parts.Add("содержит цикл");
            if (Regex.IsMatch(text, @"\b(if|elif|else)\b")) parts.Add("содержит условную ветку");
            if (Regex.IsMatch(text, @"\b(import|from)\b")) parts.Add("подключает модуль");
            if (Regex.IsMatch(text, @"\b(try|except|finally)\b")) parts.Add("обрабатывает исключения");
            if (Regex.IsMatch(text, @"\b(return|yield)\b")) parts.Add("возвращает результат или промежуточные значения");
            if (Regex.IsMatch(text, @"\[.*\bfor\b.*\]", RegexOptions.Singleline)) parts.Add("создаёт списковое включение");
            if (Regex.IsMatch(text, @"\bwith\b")) parts.Add("использует контекстный менеджер");
            if (Regex.IsMatch(text, @"\b(match|case)\b")) parts.Add("сопоставляет значение с вариантами");
            if (Regex.IsMatch(text, @"\braise\b")) parts.Add("выбрасывает исключение");
            if (Regex.IsMatch(text, @"\blambda\b")) parts.Add("создаёт анонимную функцию");
            if (Regex.IsMatch(text, @"^\s*@\w+", RegexOptions.Multiline)) parts.Add("использует декоратор");
        }
        else
        {
            if (Regex.IsMatch(text, @"#\s*include")) parts.Add("подключает заголовочный файл");
            if (Regex.IsMatch(text, @"#\s*define")) parts.Add("создаёт макрос препроцессора");
            if (Regex.IsMatch(text, @"\b(class|struct)\s+\w+")) parts.Add("объявляет пользовательский тип");
            if (Regex.IsMatch(text, @"\b(for|while|do)\b")) parts.Add("содержит цикл");
            if (Regex.IsMatch(text, @"\b(if|else|switch|case)\b")) parts.Add("содержит условный выбор");
            if (Regex.IsMatch(text, @"\b(try|catch|throw)\b")) parts.Add("использует исключения");
            if (Regex.IsMatch(text, @"\b(std::|vector|string|map|set)\b")) parts.Add("использует элементы стандартной библиотеки");
            if (Regex.IsMatch(text, @"\b(main)\s*\(")) parts.Add("содержит точку входа программы");
            if (Regex.IsMatch(text, @"\b(return)\b")) parts.Add("возвращает значение из функции");
            if (Regex.IsMatch(text, @"\b(namespace|using)\b")) parts.Add("работает с пространством имён или псевдонимом");
            if (Regex.IsMatch(text, @"\b(template|concept|requires)\b")) parts.Add("использует обобщённое программирование");
            if (Regex.IsMatch(text, @"\b(enum|union)\b")) parts.Add("объявляет специальный пользовательский тип");
            if (Regex.IsMatch(text, @"\b(virtual|override)\b")) parts.Add("использует полиморфизм");
            if (Regex.IsMatch(text, @"\b(constexpr|consteval)\b")) parts.Add("вычисляет часть кода на этапе компиляции");
        }

        if (Regex.IsMatch(text, @"//|#(?!include)") || text.Contains("\"\"\"") || text.Contains("'''"))
        {
            parts.Add("содержит комментарий или документирующую строку");
        }
        return parts.Count > 0 ? "Фрагмент " + string.Join(", ", parts) + "." : "структура фрагмента требует более подробного контекста.";
    }

    private static List<string> BuildSyntaxHints(string text, ProgrammingLanguage language)
    {
        var hints = new List<string>();
        if (Regex.IsMatch(text, @"(?<![=!<>])=(?!=)")) hints.Add("есть присваивание значения");
        if (Regex.IsMatch(text, @"==|!=|<=|>=|<|>")) hints.Add("есть сравнение значений");
        if (Regex.IsMatch(text, @"\b(and|or|not)\b|&&|\|\||!")) hints.Add("используется логическая операция");
        if (Regex.IsMatch(text, @"\+\+|--|\+=|-=|\*=|/=|\+|-|\*|/")) hints.Add("используется арифметическая или составная операция");
        if (Regex.IsMatch(text, @"\b\w+\s*\(")) hints.Add("вызывается функция или метод");
        if (language == ProgrammingLanguage.Cpp && Regex.IsMatch(text, @"::|->|\*\s*\w+|\w+\s*&")) hints.Add("используется обращение к пространству имён, члену, указателю или ссылке");
        if (language == ProgrammingLanguage.Cpp && Regex.IsMatch(text, @"<<|>>")) hints.Add("используется потоковый ввод или вывод");
        if (language == ProgrammingLanguage.Python && Regex.IsMatch(text, @"\b\w+\s*\[.*\]")) hints.Add("обращение к элементу по индексу или ключу");
        if (language == ProgrammingLanguage.Python && Regex.IsMatch(text, @"\*\w+|\*\*\w+")) hints.Add("распаковываются аргументы функции");
        if (language == ProgrammingLanguage.Python && Regex.IsMatch(text, @"f[""']")) hints.Add("используется форматированная строка");
        return hints;
    }
}
